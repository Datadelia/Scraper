from flask import Flask, request, jsonify
import requests
from bs4 import BeautifulSoup
import validators
import re
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  # Disable SSL warning

app = Flask(__name__)

def is_valid_url(url):
    """Check if the URL is valid and uses HTTP or HTTPS scheme."""
    return validators.url(url) and (url.startswith('https://') or url.startswith('http://'))

@app.route('/scrape', methods=['POST'])
def scrape_and_return():
    data = request.get_json()
    target_url = data.get('url')
    
    if not target_url or not is_valid_url(target_url):
        return jsonify({'error': 'Invalid URL provided, only HTTP and HTTPS URLs are allowed'}), 400
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    
    try:
        # Disable SSL certificate verification
        response = requests.get(target_url, headers=headers, timeout=10, verify=False)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            body_text = soup.find('body').get_text()
            cleaned_text = re.sub(r'\s+', ' ', body_text).strip()
            return jsonify({'scraped_data': cleaned_text}), 200
        else:
            return jsonify({'error': 'Failed to retrieve the web page, status code: ' + str(response.status_code)}), response.status_code
    except requests.RequestException as e:
        return jsonify({'error': 'Request failed: ' + str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
